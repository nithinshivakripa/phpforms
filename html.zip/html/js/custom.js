$(function() {
    $('.owl-carousel.testimonial-carousel').owlCarousel({
      nav: true,
      navText: ['<i class="flaticon-back"></i>', '<i class="flaticon-right-arrow"></i>'],
      dots: false,
      responsive: {
        0: {
          items: 1,
        },
        750: {
          items: 2,
        }
      }
    });
  });





  $(document).ready(function() {
    $('.pgwSlider').pgwSlider();
});
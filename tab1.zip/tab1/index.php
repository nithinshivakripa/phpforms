<?php
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', 'root');
define('DB_NAME', 'blog');

$link = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
$title = $category = $content ="";
$title_error = $category_error = $content_error ="";
$display_error = "";
$display ="";

if($_SERVER["REQUEST_METHOD"] == "POST"){
  if(empty(trim($_POST["category"]))){
     $category_error = "Please select a category";
 } else{
     $category = trim($_POST["category"]);
 }
  if(empty(trim($_POST["title"]))){
     $title_error = "Please enter a title";
 } else{
     $title = trim($_POST["title"]);
 }
 if(empty(trim($_POST["content"]))){
    $content_error = "Please enter a content";
} else{
    $content = trim($_POST["content"]);
}


if(empty($title_error) && empty($content_error)){

       // Prepare an insert statement
       $sql = "INSERT INTO user (title, category, content) VALUES (?, ?, ?)";

       if($stmt = mysqli_prepare($link, $sql)){
           // Bind variables to the prepared statement as parameters
           mysqli_stmt_bind_param($stmt, "sss", $param_title, $param_category, $param_content);

           // Set parameters
           $param_title = $title;
           $param_category = $category;
           $param_content = $content;

           // Attempt to execute the prepared statement
           if(mysqli_stmt_execute($stmt)){
               // Redirect to login page

           } else{
               echo "Something went wrong. Please try again later.";
           }
       }

       // Close statement
       mysqli_stmt_close($stmt);
   }

   // Close connection
    // mysqli_close($link);
}

?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

</head>
<body>
<div class="container">
<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
  <div class="row">
    <div class="col-25">
      <label for="category">Category</label>
    </div>
    <div class="col-75">
      <select name="category">
          <option  value="">....</option>
          <option  value="Sports">Sports</option>
          <option  value="Politics">Politics</option>
          <option  value="Article">Article</option>
        </select>
      <span class="error"><?php echo $category_error; ?></span>
    </div>
  </div>
    <div class="row">
      <div class="col-25">
        <label for="title">Title</label>
      </div>
      <div class="col-75">
        <input type="text" id="title" name="title"  placeholder="Title">
        <span class="error"><?php echo $title_error; ?></span>
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="content">Content</label>
      </div>
      <div class="col-75">
        <textarea id="content" name="content"  placeholder="Write something.." style="height:200px"></textarea>
        <span class="error"><?php echo $content_error; ?></span>
      </div>
    </div>
    <div class="row">
      <input type="submit" value="Submit">
    </div>
  </form>
</div>
<div class="container">
  <div class="row">
    <div class="col-25">
      <form class="display">
        <div id="dd" class="wrapper-dropdown-2">

          <select class="dropdown" name="category" onchange="showUser(this.value)">
            <option  value="">Select Category</option>
            <option  value="Sports"><i class="icon-twitter icon-large">&#9755;</i>Sports</option>
            <option  value="Politics"><i class="icon-twitter icon-large">&#9755;</i>Politics</option>
            <option  value="Article"><i class="icon-twitter icon-large">&#9755;</i>Article</option>
          </select>
        </div>
      </form>

  </div>


  <div id="txtHint"><b>Information will be listed here.</b></div>

<table id="demo"></table>
</div>
</div>

<script>
function showUser(str) {
  if (str=="") {
    document.getElementById("txtHint").innerHTML="";
    return;
  }
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (this.readyState==4 && this.status==200) {
      document.getElementById("txtHint").innerHTML=this.responseText;
    }
  }
  xmlhttp.open("GET","welcome.php?q="+str,true);
  xmlhttp.send();
}
</script>


</body>
</html>

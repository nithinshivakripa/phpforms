<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" >
<body>

<?php
$category = $_REQUEST["q"];

$con = mysqli_connect('localhost','root','root','blog');
if (!$con) {
    die('Could not connect: ' . mysqli_error($con));
}

mysqli_select_db($con,"ajax_demo");
$sql="SELECT * FROM user WHERE category = '".$category."'";
$result = mysqli_query($con,$sql);

echo "<div class='content_cat'>";
while($row = mysqli_fetch_array($result)) {

    echo "<h2>" . $row['title'] . "</h2>";
    echo "<p>" . $row['content'] . "</p>";
    echo "<p>" . $row['category'] . "</p>";

}
echo "</div>";
mysqli_close($con);
?>
</body>
</html>

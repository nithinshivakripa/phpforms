<?php  

class DashboardCoreCommercePaymentController extends DashboardBaseController {

	public function view() {		
		$this->redirect('/dashboard/core_commerce/payment/methods');
	}
	


}
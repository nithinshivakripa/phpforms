<?php  

class DashboardCoreCommerceOrdersController extends Controller {

	public function view() {
		$this->redirect('/dashboard/core_commerce/orders/search');
	}


}
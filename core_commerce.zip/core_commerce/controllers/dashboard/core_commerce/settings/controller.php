<?php  

class DashboardCoreCommerceSettingsController extends Controller {


	
}

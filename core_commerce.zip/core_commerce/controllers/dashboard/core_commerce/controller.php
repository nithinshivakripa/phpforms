<?php  

class DashboardCoreCommerceController extends Controller {
	public function view() {
		$this->redirect('/dashboard/core_commerce/products/');
	}
}

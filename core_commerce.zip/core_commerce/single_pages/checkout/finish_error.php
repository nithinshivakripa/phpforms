<?php 
Loader::model('order/current', 'core_commerce');
?>

<div id="ccm-core-commerce-checkout-cart">

<p><?php echo t('We are unable to complete processing of your order at this time.  Please try again later.')?></p>

</div>

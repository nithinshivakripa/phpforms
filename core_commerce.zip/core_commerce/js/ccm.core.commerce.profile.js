$(function() {
	$('div.ccm-core-commerce-profile-order-list-row').click(function() {
		$(this).find('div.ccm-core-commerce-profile-order-list-products').toggle();
	}); 

});
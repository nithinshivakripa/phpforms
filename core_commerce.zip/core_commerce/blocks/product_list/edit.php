<?php 
defined('C5_EXECUTE') or die(_("Access Denied."));

//include(DIR_FILES_BLOCK_TYPES.'/contact_directory/form_setup_html.php');

$bt->inc('elements/form_setup_html.php', array( 'c'=>$c, 'b'=>$b, 'controller'=>$controller  ) ); 
?>


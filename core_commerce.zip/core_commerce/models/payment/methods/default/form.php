<?php echo t("Click 'Next' to submit your payment to the Default Gateway."); ?>
